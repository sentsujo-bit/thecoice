package br.nait.evento;
import org.bukkit.ChatColor;
import org.bukkit.plugin.java.JavaPlugin;
public final class EventoPlugin extends JavaPlugin {
 private EventManager manager;
 @Override public void onEnable(){saveDefaultConfig(); manager=new EventManager(this); getServer().getPluginManager().registerEvents(manager,this); EventoCommand c=new EventoCommand(this); getCommand("evento").setExecutor(c); getCommand("evento").setTabCompleter(c); getLogger().info("Evento ativado.");}
 public EventManager manager(){return manager;}
 public static String color(String s){return ChatColor.translateAlternateColorCodes('&',s);}
}
