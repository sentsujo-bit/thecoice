package br.nait.evento;
import org.bukkit.command.*; import org.bukkit.entity.Player; import java.util.*;
public final class EventoCommand implements CommandExecutor,TabCompleter{
 private final EventoPlugin p; public EventoCommand(EventoPlugin p){this.p=p;}
 public boolean onCommand(CommandSender s,Command c,String l,String[] a){
  if(a.length==0){help(s);return true;} String sub=a[0].toLowerCase();
  if(sub.equals("iniciar")){if(!s.hasPermission("evento.admin")){s.sendMessage(EventoPlugin.color("&cSem permissão."));return true;} if(a.length<2){s.sendMessage(EventoPlugin.color("&cUse /evento iniciar lava|manhunt [spin]"));return true;} EventMode m=a[1].equalsIgnoreCase("lava")?EventMode.LAVA:a[1].equalsIgnoreCase("manhunt")?EventMode.MANHUNT:null; if(m==null){s.sendMessage(EventoPlugin.color("&cModo inválido."));return true;} boolean spin=a.length>2&&a[2].equalsIgnoreCase("spin");p.manager().start(m,spin);return true;}
  if(sub.equals("entrar")){if(s instanceof Player x)p.manager().join(x);return true;}
  if(sub.equals("sair")){if(s instanceof Player x)p.manager().leave(x);return true;}
  if(sub.equals("status")){p.manager().status(s);return true;}
  if(sub.equals("parar")){if(!s.hasPermission("evento.admin")){s.sendMessage(EventoPlugin.color("&cSem permissão."));return true;}p.manager().stop("&cEvento encerrado pelo administrador.");return true;}
  help(s);return true;
 }
 private void help(CommandSender s){s.sendMessage(EventoPlugin.color("&b/evento iniciar lava"));s.sendMessage(EventoPlugin.color("&b/evento iniciar manhunt [spin]"));s.sendMessage(EventoPlugin.color("&b/evento entrar &7| &b/evento sair"));s.sendMessage(EventoPlugin.color("&b/evento status &7| &b/evento parar"));}
 public List<String> onTabComplete(CommandSender s,Command c,String l,String[] a){if(a.length==1)return Arrays.asList("iniciar","entrar","sair","status","parar");if(a.length==2&&a[0].equalsIgnoreCase("iniciar"))return Arrays.asList("lava","manhunt");if(a.length==3&&a[0].equalsIgnoreCase("iniciar")&&a[1].equalsIgnoreCase("manhunt"))return List.of("spin");return List.of();}
}
